import React, { useEffect, useState, createContext, useContext } from 'react';
import {
  User,
  Recipe,
  Notification,
  MOCK_USERS,
  MOCK_RECIPES,
  MOCK_NOTIFICATIONS } from
'../data/mockData';
import { sanitizeText, sanitizeArray } from '../utils/sanitize';
type AppContextType = {
  currentUser: User | null;
  login: (
  method: string,
  userDetails?: {
    name: string;
    email: string;
    phone: string;
  })
  => void;
  logout: () => void;
  recipes: Recipe[];
  addRecipe: (
  recipe: Omit<Recipe, 'id' | 'likes' | 'comments' | 'status' | 'createdAt'>)
  => void;
  updateRecipeStatus: (id: string, status: 'approved' | 'rejected') => void;
  addComment: (recipeId: string, text: string) => void;
  savedRecipeIds: string[];
  toggleSave: (id: string) => void;
  likedRecipeIds: string[];
  toggleLike: (id: string) => void;
  notifications: Notification[];
  markNotificationsRead: () => void;
  users: Record<string, User>;
};
const AppContext = createContext<AppContextType | undefined>(undefined);
// Helper to load from localStorage
function loadState<T>(key: string, defaultVal: T): T {
  try {
    const saved = localStorage.getItem(`sethkusina_${key}`);
    return saved ? JSON.parse(saved) : defaultVal;
  } catch {
    return defaultVal;
  }
}
export function AppProvider({ children }: {children: ReactNode;}) {
  const [currentUser, setCurrentUser] = useState<User | null>(() =>
  loadState('currentUser', null)
  );
  const [recipes, setRecipes] = useState<Recipe[]>(() =>
  loadState('recipes', MOCK_RECIPES)
  );
  const [savedRecipeIds, setSavedRecipeIds] = useState<string[]>(() =>
  loadState('saved', [])
  );
  const [likedRecipeIds, setLikedRecipeIds] = useState<string[]>(() =>
  loadState('liked', [])
  );
  const [notifications, setNotifications] = useState<Notification[]>(() =>
  loadState('notifs', MOCK_NOTIFICATIONS)
  );
  const [users, setUsers] = useState<Record<string, User>>(() =>
  loadState('users', MOCK_USERS)
  );
  // Persist state changes
  useEffect(() => {
    localStorage.setItem('sethkusina_currentUser', JSON.stringify(currentUser));
  }, [currentUser]);
  useEffect(() => {
    localStorage.setItem('sethkusina_recipes', JSON.stringify(recipes));
  }, [recipes]);
  useEffect(() => {
    localStorage.setItem('sethkusina_saved', JSON.stringify(savedRecipeIds));
  }, [savedRecipeIds]);
  useEffect(() => {
    localStorage.setItem('sethkusina_liked', JSON.stringify(likedRecipeIds));
  }, [likedRecipeIds]);
  useEffect(() => {
    localStorage.setItem('sethkusina_notifs', JSON.stringify(notifications));
  }, [notifications]);
  useEffect(() => {
    localStorage.setItem('sethkusina_users', JSON.stringify(users));
  }, [users]);
  const login = (
  method: string,
  userDetails?: {
    name: string;
    email: string;
    phone: string;
  }) =>
  {
    if (method === 'admin') {
      setCurrentUser(users['admin']);
    } else if (userDetails) {
      // Create or find user based on email
      const existingUser = Object.values(users).find(
        (u) => u.email === userDetails.email
      );
      if (existingUser) {
        setCurrentUser(existingUser);
      } else {
        const newId = `u_${Date.now()}`;
        const newUser: User = {
          id: newId,
          username: sanitizeText(userDetails.name, 50),
          email: userDetails.email,
          phone: userDetails.phone,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userDetails.name}`,
          followers: 0,
          following: 0,
          likes: 0,
          role: 'user'
        };
        setUsers((prev) => ({
          ...prev,
          [newId]: newUser
        }));
        setCurrentUser(newUser);
      }
    } else {
      setCurrentUser(users['u2']);
    }
  };
  const logout = () => setCurrentUser(null);
  const addRecipe = (
  recipeData: Omit<
    Recipe,
    'id' | 'likes' | 'comments' | 'status' | 'createdAt'>) =>

  {
    // SECURITY: Sanitize all user inputs before storing
    const newRecipe: Recipe = {
      title: sanitizeText(recipeData.title, 100),
      description: sanitizeText(recipeData.description, 1000),
      category: recipeData.category,
      image: recipeData.image,
      ingredients: sanitizeArray(recipeData.ingredients, 200),
      steps: sanitizeArray(recipeData.steps, 500),
      authorId: recipeData.authorId,
      id: `r${Date.now()}`,
      likes: 0,
      comments: [],
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setRecipes([newRecipe, ...recipes]);
  };
  const updateRecipeStatus = (id: string, status: 'approved' | 'rejected') => {
    setRecipes(
      recipes.map((r) =>
      r.id === id ?
      {
        ...r,
        status
      } :
      r
      )
    );
  };
  const addComment = (recipeId: string, text: string) => {
    if (!currentUser) return;
    // SECURITY: Sanitize comment text
    const cleanText = sanitizeText(text, 500);
    if (!cleanText) return;
    setRecipes(
      recipes.map((r) => {
        if (r.id === recipeId) {
          return {
            ...r,
            comments: [
            ...r.comments,
            {
              id: `c${Date.now()}`,
              authorId: currentUser.id,
              text: cleanText,
              timestamp: 'Just now'
            }]

          };
        }
        return r;
      })
    );
  };
  const toggleSave = (id: string) => {
    setSavedRecipeIds((prev) =>
    prev.includes(id) ?
    prev.filter((savedId) => savedId !== id) :
    [...prev, id]
    );
  };
  const toggleLike = (id: string) => {
    setLikedRecipeIds((prev) => {
      const isLiked = prev.includes(id);
      setRecipes(
        recipes.map((r) =>
        r.id === id ?
        {
          ...r,
          likes: isLiked ? r.likes - 1 : r.likes + 1
        } :
        r
        )
      );
      return isLiked ? prev.filter((likedId) => likedId !== id) : [...prev, id];
    });
  };
  const markNotificationsRead = () => {
    setNotifications(
      notifications.map((n) => ({
        ...n,
        read: true
      }))
    );
  };
  return (
    <AppContext.Provider
      value={{
        currentUser,
        login,
        logout,
        recipes,
        addRecipe,
        updateRecipeStatus,
        addComment,
        savedRecipeIds,
        toggleSave,
        likedRecipeIds,
        toggleLike,
        notifications,
        markNotificationsRead,
        users
      }}>
      
      {children}
    </AppContext.Provider>);

}
export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}