import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  Mail,
  User as UserIcon,
  Phone,
  ArrowLeft,
  ShieldCheck,
  CheckCircle2 } from
'lucide-react';
import { useAppContext } from '../context/AppContext';
import { checkRateLimit, formatRemainingTime } from '../utils/rateLimit';
type Step = 'details' | 'verify' | 'success';
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Common disposable/throwaway domains we treat as "fake"
const DISPOSABLE_DOMAINS = [
'mailinator.com',
'tempmail.com',
'temp-mail.org',
'10minutemail.com',
'guerrillamail.com',
'trashmail.com',
'yopmail.com',
'sharklasers.com',
'fakeinbox.com',
'throwawaymail.com'];

export function AuthModal({
  isOpen,
  onClose



}: {isOpen: boolean;onClose: () => void;}) {
  const { login } = useAppContext();
  const [step, setStep] = useState<Step>('details');
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [errors, setErrors] = useState<{
    [k: string]: string;
  }>({});
  const [sentCode, setSentCode] = useState('');
  const [enteredCode, setEnteredCode] = useState('');
  const [codeError, setCodeError] = useState('');
  if (!isOpen) return null;
  const reset = () => {
    setStep('details');
    setForm({
      name: '',
      email: '',
      phone: ''
    });
    setErrors({});
    setSentCode('');
    setEnteredCode('');
    setCodeError('');
  };
  const handleClose = () => {
    reset();
    onClose();
  };
  const validateDetails = () => {
    const next: {
      [k: string]: string;
    } = {};
    if (!form.name.trim()) next.name = 'Ilagay ang pangalan mo.';
    const email = form.email.trim().toLowerCase();
    if (!email) {
      next.email = 'Kailangan ng email.';
    } else if (!EMAIL_REGEX.test(email)) {
      next.email = 'Mukhang hindi tama ang email na ito.';
    } else if (DISPOSABLE_DOMAINS.includes(email.split('@')[1])) {
      next.email = 'Hindi tanggap ang temporary/fake email.';
    }
    const phone = form.phone.replace(/[\s-]/g, '');
    if (!phone) {
      next.phone = 'Kailangan ng number.';
    } else if (!/^(\+?\d{7,15})$/.test(phone)) {
      next.phone = 'Mukhang hindi tama ang number na ito.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };
  const handleSendCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateDetails()) return;
    // Rate limit code requests (max 3 per minute)
    const limit = checkRateLimit({
      key: 'auth_code',
      maxAttempts: 3,
      windowMs: 60000
    });
    if (!limit.allowed) {
      setErrors({
        ...errors,
        phone: `Masyadong mabilis. Maghintay ng ${formatRemainingTime(limit.remainingMs!)}.`
      });
      return;
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSentCode(code);
    setStep('verify');
  };
  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredCode.trim() !== sentCode) {
      setCodeError('Mali ang code. Subukan ulit.');
      return;
    }
    setStep('success');
  };
  const handleConfirm = () => {
    login('email', form);
    handleClose();
  };
  return (
    <AnimatePresence>
      {isOpen &&
      <>
          <motion.div
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          exit={{
            opacity: 0
          }}
          className="fixed inset-0 bg-black/60 z-50 backdrop-blur-sm"
          onClick={handleClose} />
        
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
            <motion.div
            initial={{
              opacity: 0,
              scale: 0.95,
              y: 20
            }}
            animate={{
              opacity: 1,
              scale: 1,
              y: 0
            }}
            exit={{
              opacity: 0,
              scale: 0.95,
              y: 20
            }}
            className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-xl max-h-[90vh] overflow-y-auto pointer-events-auto">
            
              <button
              onClick={handleClose}
              aria-label="Close"
              className="absolute right-4 top-4 p-2 text-stone-400 hover:text-stone-600 bg-stone-100 rounded-full z-10">
              
                <X className="w-5 h-5" />
              </button>

              {step === 'details' &&
            <>
                  <div className="text-center mb-8 mt-4 px-6">
                    <h2 className="text-3xl font-display font-bold text-stone-900 mb-2">
                      Sali na sa SethKusina
                    </h2>
                    <p className="text-stone-500">
                      Ilagay ang detalye mo para makapag-login.
                    </p>
                  </div>

                  <form
                onSubmit={handleSendCode}
                className="space-y-4"
                noValidate>
                
                    <div>
                      <label className="block text-sm font-bold text-stone-700 mb-1.5">
                        Pangalan
                      </label>
                      <div className="relative">
                        <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                        <input
                      type="text"
                      value={form.name}
                      onChange={(e) =>
                      setForm({
                        ...form,
                        name: e.target.value
                      })
                      }
                      placeholder="hal., Juan Dela Cruz"
                      className="w-full bg-stone-50 border border-stone-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 rounded-xl py-3 pl-10 pr-4 outline-none transition-all" />
                    
                      </div>
                      {errors.name &&
                  <p className="text-sm text-red-500 mt-1">
                          {errors.name}
                        </p>
                  }
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-stone-700 mb-1.5">
                        Email
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                        <input
                      type="email"
                      value={form.email}
                      onChange={(e) =>
                      setForm({
                        ...form,
                        email: e.target.value
                      })
                      }
                      placeholder="hal., juan@gmail.com"
                      className="w-full bg-stone-50 border border-stone-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 rounded-xl py-3 pl-10 pr-4 outline-none transition-all" />
                    
                      </div>
                      {errors.email &&
                  <p className="text-sm text-red-500 mt-1">
                          {errors.email}
                        </p>
                  }
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-stone-700 mb-1.5">
                        Numero
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                        <input
                      type="tel"
                      value={form.phone}
                      onChange={(e) =>
                      setForm({
                        ...form,
                        phone: e.target.value
                      })
                      }
                      placeholder="hal., 0917 123 4567"
                      className="w-full bg-stone-50 border border-stone-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 rounded-xl py-3 pl-10 pr-4 outline-none transition-all" />
                    
                      </div>
                      {errors.phone &&
                  <p className="text-sm text-red-500 mt-1">
                          {errors.phone}
                        </p>
                  }
                    </div>

                    <button
                  type="submit"
                  className="w-full bg-stone-900 text-white py-3.5 rounded-xl font-semibold hover:bg-stone-800 transition-colors mt-2">
                  
                      Magpadala ng Code
                    </button>
                  </form>

                  <div className="mt-6 pt-6 border-t border-stone-100 text-center">
                    <button
                  onClick={() => {
                    login('admin');
                    handleClose();
                  }}
                  className="text-sm text-stone-400 hover:text-primary-600 font-medium">
                  
                      Pumasok bilang Admin (Demo)
                    </button>
                  </div>
                </>
            }

              {step === 'verify' &&
            <>
                  <button
                onClick={() => {
                  setStep('details');
                  setCodeError('');
                  setEnteredCode('');
                }}
                className="flex items-center gap-1 text-sm text-stone-400 hover:text-stone-600 font-medium mb-2 mt-2">
                
                    <ArrowLeft className="w-4 h-4" /> Bumalik
                  </button>

                  <div className="text-center mb-6 px-4">
                    <div className="w-16 h-16 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <ShieldCheck className="w-8 h-8" />
                    </div>
                    <h2 className="text-2xl font-display font-bold text-stone-900 mb-2">
                      I-verify ang Email mo
                    </h2>
                    <p className="text-stone-500 text-sm">
                      Nagpadala kami ng 6-digit code sa{' '}
                      <span className="font-semibold text-stone-700">
                        {form.email}
                      </span>
                      .
                    </p>
                  </div>

                  {/* Demo notice — no backend is connected to send real email */}
                  <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-xl p-3 mb-4 text-center">
                    Demo mode: ang code mo ay{' '}
                    <span className="font-bold tracking-widest">
                      {sentCode}
                    </span>
                  </div>

                  <form onSubmit={handleVerify} className="space-y-4">
                    <input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={enteredCode}
                  onChange={(e) => {
                    setEnteredCode(e.target.value.replace(/\D/g, ''));
                    setCodeError('');
                  }}
                  placeholder="------"
                  className="w-full text-center text-2xl tracking-[0.5em] font-bold bg-stone-50 border border-stone-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 rounded-xl py-4 outline-none transition-all" />
                
                    {codeError &&
                <p className="text-sm text-red-500 text-center">
                        {codeError}
                      </p>
                }
                    <button
                  type="submit"
                  className="w-full bg-primary-500 text-white py-3.5 rounded-xl font-semibold hover:bg-primary-600 transition-colors">
                  
                      I-verify ang Code
                    </button>
                  </form>
                </>
            }

              {step === 'success' &&
            <div className="text-center py-6 px-4">
                  <motion.div
                initial={{
                  scale: 0.6,
                  opacity: 0
                }}
                animate={{
                  scale: 1,
                  opacity: 1
                }}
                transition={{
                  type: 'spring',
                  stiffness: 260,
                  damping: 18
                }}
                className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                
                    <CheckCircle2 className="w-11 h-11" />
                  </motion.div>
                  <h2 className="text-2xl font-display font-bold text-stone-900 mb-2">
                    Confirmed na, boss!
                  </h2>
                  <p className="text-stone-500 mb-2">
                    Na-verify na ang account mo.
                  </p>
                  <p className="text-stone-700 font-semibold mb-8">
                    Welcome, {form.name || 'Chef'}!
                  </p>
                  <button
                onClick={handleConfirm}
                className="w-full bg-primary-500 text-white py-3.5 rounded-xl font-semibold hover:bg-primary-600 transition-colors">
                
                    Magpatuloy
                  </button>
                </div>
            }
            </motion.div>
          </div>
        </>
      }
    </AnimatePresence>);

}