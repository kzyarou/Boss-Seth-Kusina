export type User = {
  id: string;
  username: string;
  avatar: string;
  followers: number;
  following: number;
  likes: number;
  isVerified?: boolean;
  role: 'user' | 'admin';
  email?: string;
  phone?: string;
};

export type Comment = {
  id: string;
  authorId: string;
  text: string;
  timestamp: string;
};

export type Recipe = {
  id: string;
  title: string;
  description: string;
  authorId: string;
  category: string;
  image: string;
  ingredients: string[];
  steps: string[];
  likes: number;
  comments: Comment[];
  status: 'approved' | 'pending' | 'rejected';
  createdAt: string;
};

export type Notification = {
  id: string;
  type: 'like' | 'comment' | 'feature' | 'system';
  text: string;
  read: boolean;
  timestamp: string;
};

export const MOCK_USERS: Record<string, User> = {
  u1: {
    id: 'u1',
    username: 'Boss Seth',
    avatar:
    'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=150&q=80',
    followers: 1250000,
    following: 12,
    likes: 5400000,
    isVerified: true,
    role: 'admin',
    email: 'seth@sethkusina.com',
    phone: '09171234567'
  },
  u2: {
    id: 'u2',
    username: 'ChefJuan',
    avatar:
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    followers: 120,
    following: 45,
    likes: 532,
    role: 'user',
    email: 'juan@example.com',
    phone: '09181234567'
  },
  u3: {
    id: 'u3',
    username: 'MariaCooks',
    avatar:
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80',
    followers: 890,
    following: 120,
    likes: 3400,
    role: 'user',
    email: 'maria@example.com',
    phone: '09191234567'
  },
  admin: {
    id: 'admin',
    username: 'Admin',
    avatar:
    'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&w=150&q=80',
    followers: 0,
    following: 0,
    likes: 0,
    role: 'admin',
    email: 'admin@sethkusina.com',
    phone: '09201234567'
  }
};

export const CATEGORIES = [
{
  id: 'boss-seth',
  name: 'Mga Trip ni Boss Seth',
  color: 'bg-primary-100 text-primary-700'
},
{
  id: 'community',
  name: 'Eksperimento ng Bayan',
  color: 'bg-purple-100 text-purple-700'
},
{
  id: 'budget',
  name: 'Petsa de Peligro Meals',
  color: 'bg-green-100 text-green-700'
},
{
  id: 'traditional',
  name: 'Luto ni Nanay',
  color: 'bg-blue-100 text-blue-700'
}];


export const MOCK_RECIPES: Recipe[] = [];

export const MOCK_NOTIFICATIONS: Notification[] = [];